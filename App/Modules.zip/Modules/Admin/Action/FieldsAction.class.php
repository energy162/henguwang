<?php
/**
 * 系统配置类
 * @author  <[c@easycms.cc]>
 */
class FieldsAction extends CommonAction{
	
}